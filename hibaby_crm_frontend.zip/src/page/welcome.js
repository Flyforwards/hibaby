import React, { Component } from 'react';


class welcome extends Component {

  render() {

    return (
      <div>
        <div>
        </div>
        <div >
          还没有添加此菜单，用这个页面代替
        </div>
      </div>

    )
  }
}

export default welcome;
