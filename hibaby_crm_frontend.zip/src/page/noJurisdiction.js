import React, { Component } from 'react';


class noJurisdiction extends Component {

  render() {

    return (
      <div>
        <div>
        </div>
        <div >
          没有权限访问这个菜单
        </div>
      </div>
    )
  }
}

export default noJurisdiction;
